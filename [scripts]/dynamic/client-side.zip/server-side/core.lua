-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("dynamic",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- 
-----------------------------------------------------------------------------------------------------------------------------------------
vKEYBOARD = Tunnel.getInterface("keyboard")
vSKINSHOP = Tunnel.getInterface("skinshop")
-----------------------------------------------------------------------------------------------------------------------------------------
-- 
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand('vroupas2', function(source, args, rawCommand)
    local Passport = vRP.Passport(source)
    if Passport then
		local custom = vSKINSHOP.Customization(source)
		if custom then
        	local content = ""
			if custom['hat']['item'] then
				content = content .. '["hat"] = { item = '..custom['hat']['item']..', texture = '..custom['hat']['texture']..' },\n'    
			end
			if custom['pants']['item'] then
				content = content .. '["pants"] = { item = '..custom['pants']['item']..', texture = '..custom['pants']['texture']..' },\n'  
			end
			if custom['vest']['item'] then
				content = content .. '["vest"] = { item = '..custom['vest']['item']..', texture = '..custom['vest']['texture']..' },\n'  
			end
			if custom['bracelet']['item'] then
				content = content .. '["bracelet"] = { item = '..custom['bracelet']['item']..', texture = '..custom['bracelet']['texture']..' },\n'  
			end
			if custom['backpack']['item'] then
				content = content .. '["backpack"] = { item = '..custom['backpack']['item']..', texture = '..custom['backpack']['texture']..' },\n'  
			end
			if custom['decals']['item'] then
				content = content .. '["decals"] = { item = '..custom['decals']['item']..', texture = '..custom['decals']['texture']..' },\n'  
			end
			if custom['mask']['item'] then
				content = content .. '["mask"] = { item = '..custom['mask']['item']..', texture = '..custom['mask']['texture']..' },\n'  
			end
			if custom['shoes']['item'] then
				content = content .. '["shoes"] = { item = '..custom['shoes']['item']..', texture = '..custom['shoes']['texture']..' },\n'  
			end
			if custom['tshirt']['item'] then
				content = content .. '["tshirt"] = { item = '..custom['tshirt']['item']..', texture = '..custom['tshirt']['texture']..' },\n'  
			end
			if custom['torso']['item'] then
				content = content .. '["torso"] = { item = '..custom['torso']['item']..', texture = '..custom['torso']['texture']..' },\n'  
			end
			if custom['accessory']['item'] then
				content = content .. '["accessory"] = { item = '..custom['accessory']['item']..', texture = '..custom['accessory']['texture']..' },\n'  
			end
			if custom['watch']['item'] then
				content = content .. '["watch"] = { item = '..custom['watch']['item']..', texture = '..custom['watch']['texture']..' },\n'  
			end
			if custom['arms']['item'] then
				content = content .. '["arms"] = { item = '..custom['arms']['item']..', texture = '..custom['arms']['texture']..' },\n'  
			end
			if custom['glass']['item'] then
				content = content .. '["glass"] = { item = '..custom['glass']['item']..', texture = '..custom['glass']['texture']..' },\n'  
			end
			if custom['ear']['item'] then
				content = content .. '["ear"] = { item = '..custom['ear']['item']..', texture = '..custom['ear']['texture']..' }'  
			end
        	vKEYBOARD.Copy(source,"vRoupas:",content)
		end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXCLUSIVAS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Exclusivas()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Clothes = {}
		local Consult = vRP.GetSrvData("Exclusivas:"..Passport)
		for Index,v in pairs(Consult) do
			Clothes[#Clothes + 1] = { ["name"] = Index, ["id"] = v["id"], ["texture"] = v["texture"] or 0, ["type"] = v["type"] }
		end
		return Clothes
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- 
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckOneOrg()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Permission = vRP.GetUserType(Passport, "Favela")
		if Permission then
			return vRP.HasPermission(Passport, Permission, 1)
		end
		return 
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXCLUSIVAS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckVip()
	local source = source
	local Passport = vRP.Passport(source)
	if vRP.HasGroup(Passport,"Premium") then
		return true
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CODES
-----------------------------------------------------------------------------------------------------------------------------------------
local Codes = {
	["13"] = {
		["Message"] = "Oficial desmaiado/ferido",
		["Blip"] = 6
	},
	["20"] = {
		["Message"] = "Localização",
		["Blip"] = 6
	},
	["38"] = {
		["Message"] = "Abordagem de trânsito",
		["Blip"] = 6
	},
	["78"] = {
		["Message"] = "Apoio com prioridade",
		["Blip"] = 6
	}
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- DYNAMIC:TENCODE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("dynamic:Tencode")
AddEventHandler("dynamic:Tencode",function(Number)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetUserType(Passport,"Policia") and Codes[Number] then
		local FullName = vRP.FullName(Passport)
		local Coords = vRP.GetEntityCoords(source)
		local Service = vRP.NumPermission("Policia")
		for Passports,Sources in pairs(Service) do
			async(function()
				vRPC.PlaySound(Sources,"ATM_WINDOW","HUD_FRONTEND_DEFAULT_SOUNDSET")
				TriggerClientEvent("NotifyPush",Sources,{ code = Number, title = Codes[Number]["Message"], x = Coords["x"], y = Coords["y"], z = Coords["z"], name = FullName, color = Codes[Number]["Blip"] })
			end)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Animal = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- CREATEANIMAL
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CreateAnimal(Model,x,y,z,h)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if Animal[Passport] then
			DeleteEntity(Animal[Passport])
		end
		Animal[Passport] = CreatePed(28,GetHashKey(Model),x,y,z,h)
		return Animal[Passport],NetworkGetNetworkIdFromEntity(Animal[Passport])
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DELETEANIMAL
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.deleteAnimal()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		DeleteEntity(Animal[Passport])
		Animal[Passport] = nil
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if Animal[Passport] then
		DeleteEntity(Animal[Passport])
		Animal[Passport] = nil
	end
end)

/*
-----------------------------------------------------------------------------------------------------------------------------------------
-- ADMIN:DYNAMIC
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("admin:Dynamic")
AddEventHandler("admin:Dynamic", function(Mode, Source)
	local source = Source or source
	local Passport = vRP.Passport(source)
	if Passport then
		TriggerClientEvent("dynamic:closeSystem", source)
		if Mode == "wl" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID da Whitelist:", "Status: (0 inativa, 1 ativa)")
				if Keyboard then
					TriggerClientEvent("Notify", source, "verde", "Whitelist editada.", 5000, "Sucesso")
					vRP.Query("accounts/SetWhitelist", { Whitelist = Keyboard[2], id = Keyboard[1] })
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "rename" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Tertiary(source, "ID:", "Nome:", "Sobrenome:")
				if Keyboard then
					vRP.UpgradeNames(Keyboard[1], Keyboard[2], Keyboard[3])
					TriggerClientEvent("Notify", source, "verde", "Nome atualizado.", 5000, "Sucesso")
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "ugroups" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local Result = ""
					local Groups = vRP.Groups()
					local OtherPassport = Keyboard[1]
					for Permission, _ in pairs(Groups) do
						local Data = vRP.DataGroups(Permission)
						if Data[OtherPassport] then
							Result = Result .."<b>Permissão:</b> " ..Permission .. "<br><b>Nível:</b> " .. Data[OtherPassport] .. "<br>"
						end
					end
					if Result ~= "" then
						TriggerClientEvent("Notify", source, "azul", Result, 10000, "Grupos Pertencentes")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "clearinv" then
			--if vRP.HasGroup(Passport, "Admin") then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					vRP.ClearInventory(Keyboard[1])
					TriggerClientEvent("Notify", source, "verde", "Limpeza concluída.", 5000, "Sucesso")
					exports["vrp"]:Embed("Admin", "**Passaporte:** " .. Passport ..
						"\n**Comando:** clearinv " .. Keyboard[1], 0xa3c846)
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "gem" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Quantidade:")
				if Keyboard then
					local Amount = parseInt(Keyboard[2])
					local OtherPassport = parseInt(Keyboard[1])
					local Identity = vRP.Identity(OtherPassport)
					if Identity then
						TriggerClientEvent("Notify", source, "verde", "Gemas entregues.", 5000, "Sucesso")
						vRP.UpgradeGemstone(OtherPassport, Amount)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "blips" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				vRPC.BlipAdmin(source)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "flash" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				TriggerClientEvent("admin:Flash", source)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "god" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					exports["vrp"]:Embed("Admin", "**Passaporte:** " .. Passport .. "\n**Comando:** god " .. Keyboard[1],
						0xa3c846)

					local OtherPassport = parseInt(Keyboard[1])
					local ClosestPed = vRP.Source(OtherPassport)
					if ClosestPed then
						vRP.UpgradeThirst(OtherPassport, 100)
						vRP.UpgradeHunger(OtherPassport, 100)
						vRP.DowngradeCough(OtherPassport, 100)
						vRP.DowngradeStress(OtherPassport, 100)
						vRP.Revive(ClosestPed, 200)

						TriggerClientEvent("paramedic:Reset", ClosestPed)

						vRPC.Destroy(ClosestPed)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "godall" then
			if vRP.HasGroup(Passport,"Admin",2) then
				local UsersList = vRP.Players()
				for k, v in pairs(UsersList) do
					local OtherPassport = parseInt(k)
					local ClosestPed = vRP.Source(OtherPassport)
					if ClosestPed then
						vRP.UpgradeThirst(OtherPassport,100)
						vRP.UpgradeHunger(OtherPassport,100)
						vRP.DowngradeCough(OtherPassport,100)
						vRP.DowngradeStress(OtherPassport,100)
						vRP.Revive(ClosestPed,200)

						TriggerClientEvent("paramedic:Reset",ClosestPed)

						vRPC.Destroy(ClosestPed)

						TriggerClientEvent("Notify", ClosestPed, "default", "Você recebeu uma cura divina.", 5000)
					end

					TriggerClientEvent("Notify", source, "verde", "Você reviveu todos onlines.", 5000, "Sucesso")
				end
			else
				TriggerClientEvent("Notify",source,"amarelo","Você não tem permissões para isso.",5000, "Atenção")
			end
		elseif Mode == "armour" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					exports["vrp"]:Embed("Admin", "**Passaporte:** " .. Passport .. "\n**Comando:** armour " ..
						Keyboard[1], 0xa3c846)

					local OtherPassport = parseInt(Keyboard[1])
					local ClosestPed = vRP.Source(OtherPassport)
					if ClosestPed then
						vRP.SetArmour(ClosestPed, 100)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "item" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "Nome do Item:", "Quantidade:")
				if Keyboard then
					if itemBody(Keyboard[1]) ~= nil then
						vRP.GenerateItem(Passport, Keyboard[1], parseInt(Keyboard[2]), true)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", "Atenção",5000)
			end
		elseif Mode == "item2" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Tertiary(source, "ID:", "Nome do Item:", "Quantidade:")
				if Keyboard then
					if itemBody(Keyboard[2]) ~= nil then
						vRP.GenerateItem(parseInt(Keyboard[1]), Keyboard[2], parseInt(Keyboard[3]), true)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "itemall" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "Nome do Item:", "Quantidade:")
				if Keyboard then
					if itemBody(Keyboard[1]) ~= nil then
						local List = vRP.Players()
						for AllPlayers, _ in pairs(List) do
							async(function()
								vRP.GenerateItem(AllPlayers, Keyboard[1], parseInt(Keyboard[2]), true)
							end)
						end
						TriggerClientEvent("Notify", source, "verde", "Envio concluído.", 5000, "Sucesso")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "delete" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					if vRP.Request(source, "Deletar Conta", "Você tem certeza?") then
						local OtherPassport = parseInt(Keyboard[1])
						vRP.Query("characters/Delete", { Passport = OtherPassport })
						TriggerClientEvent("Notify", source, "verde", "Personagem <b>" .. OtherPassport .."</b> deletado.", 5000, "Sucesso")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "skin" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Skin:")
				if Keyboard then
					local ClosestPed = vRP.Source(Keyboard[1])
					if ClosestPed then
						vRPC.Skin(ClosestPed, Keyboard[2])
						vRP.SkinCharacter(parseInt(Keyboard[1]), Keyboard[2])
						exports["vrp"]:Embed("Admin",
							"**Passaporte:** " .. Passport .. "\n**Comando:** skin " .. Keyboard[1] .. " " .. Keyboard
							[2], 0xa3c846)
						TriggerClientEvent("Notify", source, "verde",
							"Skin <b>" .. Keyboard[2] .. "</b> setada no ID " .. parseInt(Keyboard[1]) .. ".", "Sucesso",
							5000)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "resetskin" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local ClosestPed = vRP.Source(Keyboard[1])
					if ClosestPed then
						local OtherPassport = parseInt(Keyboard[1])
						local Identity = vRP.Identity(OtherPassport)
						if Identity then
							if Identity["Sex"] == "M" then
								vRPC.Skin(ClosestPed, "mp_m_freemode_01")
								vRP.SkinCharacter(parseInt(Keyboard[1]), "mp_m_freemode_01")
							elseif Identity["Sex"] == "F" then
								vRPC.Skin(ClosestPed, "mp_f_freemode_01")
								vRP.SkinCharacter(parseInt(Keyboard[1]), "mp_f_freemode_01")
							end

							exports["vrp"]:Embed("Admin",
								"**Passaporte:** " .. Passport .. "\n**Comando:** resetskin " .. Keyboard[1], 0xa3c846)
							TriggerClientEvent("Notify", source, "verde",
								"Skin do ID " .. parseInt(Keyboard[1]) .. " foi resetada.", 5000, "Sucesso")
						end
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "nc" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				vRPC.noClip(source)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "kick" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local OtherSource = vRP.Source(Keyboard[1])
					if OtherSource then
						TriggerClientEvent("Notify", source, "verde", "Passaporte <b>" .. Keyboard[1] .. "</b> expulso.",
							5000, "Sucesso")
						exports["vrp"]:Embed("Admin", "**Passaporte:** " .. Passport ..
							"\n**Comando:** kick " .. Keyboard[1], 0xa3c846)
						vRP.Kick(OtherSource, "Expulso da cidade.")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "ban" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Dias:")
				if Keyboard then
					local Days = parseInt(Keyboard[2])
					local OtherPassport = parseInt(Keyboard[1])
					local Identity = vRP.Identity(OtherPassport)
					if Identity then
						local OtherSource = vRP.Source(OtherPassport)
						if OtherSource then
							local Token = GetPlayerTokens(OtherSource)
							for k, v in pairs(Token) do
								vRP.Kick(OtherPassport, "Banido.")
								vRP.Query("banneds/InsertBanned",
									{ License = Identity["License"], Token = v, Time = Days })
							end

							exports["vrp"]:Embed("Admin",
								"**Passaporte:** " .. Passport .. "\n**Comando:** ban " .. Keyboard[1] ..
								" " .. Keyboard[2], 0xa3c846)
							TriggerClientEvent("Notify", source, "amarelo",
								"Passaporte <b>" .. OtherPassport .. "</b> banido por <b>" .. Days .. "</b> dias.",
								5000, "Atenção")
						end
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "unban" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local OtherPassport = parseInt(Keyboard[1])
					local Identity = vRP.Identity(OtherPassport)
					if Identity then
						vRP.Query("banneds/RemoveBanned", { License = Identity["License"] })
						exports["vrp"]:Embed("Admin", "**Passaporte:** " ..
							Passport .. "\n**Comando:** unban " .. Keyboard[1], 0xa3c846)
						TriggerClientEvent("Notify", source, "verde", "Passaporte <b>" ..
							OtherPassport .. "</b> desbanido.", 5000, "Sucesso")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "timeset" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Tertiary(source, "Hora:", "Minuto:", "Clima:")
				if Keyboard then
					GlobalState["Hours"] = parseInt(Keyboard[1])
					GlobalState["Minutes"] = parseInt(Keyboard[2])
					GlobalState["Weather"] = Keyboard[3]
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "temperatureset" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Primary(source, "Temperatura:")
				if Keyboard then
					GlobalState["Temperature"] = parseInt(Keyboard[1])
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "blackoutset" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				if GlobalState["Blackout"] then
					GlobalState["Blackout"] = false
					TriggerClientEvent("Notify", source, "amarelo", "Modo blackout desativado.", 5000, "Atenção")
				else
					GlobalState["Blackout"] = true
					TriggerClientEvent("Notify", source, "verde", "Modo blackout ativado.", 5000, "Sucesso")
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "cds" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Ped = GetPlayerPed(source)
				local Coords = GetEntityCoords(Ped)
				local Heading = GetEntityHeading(Ped)

				vKEYBOARD.Copy(source, "Cordenadas:",
					mathLength(Coords["x"]) ..
					"," .. mathLength(Coords["y"]) .. "," .. mathLength(Coords["z"]) .. "," .. mathLength(Heading))
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "tpcds" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Primary(source, "Coordenada:")
				if Keyboard then
					local Split = splitString(Keyboard[1], ",")
					vRP.Teleport(source, Split[1] or 0, Split[2] or 0, Split[3] or 0)
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "group" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Tertiary(source, "ID:", "Grupo:", "Hierarquia:")
				if Keyboard then
					local Level = Keyboard[3]
					local Permission = Keyboard[2]
					local OtherPassport = Keyboard[1]

					if vRP.CheckGroup(Permission) then
						if vRP.GroupType(Permission) == "Work" then
							if not vRP.GetUserType(OtherPassport, "Work") then
								exports["vrp"]:Embed("Admin",
									"**Passaporte:** " ..
									Passport .. "\n**Comando:** group " .. OtherPassport .. " " .. Permission .. " " .. Level,
									0xa3c846)
								TriggerClientEvent("Notify", source, "verde",
									"Adicionado <b>" .. Permission .. "</b> ao passaporte <b>" .. OtherPassport .. "</b>.",
									5000, "Sucesso")
								vRP.SetPermission(OtherPassport, Permission, Level)
								
								-- if exports["painel"]:Buff(Permission) > 0 then
								-- 	vRP.SetPermission(OtherPassport, "Buff")
								-- end
							else
								TriggerClientEvent("Notify", source, "amarelo", "O passaporte já pertence a outro grupo.",
									5000, "Atenção")
							end
						else
							exports["vrp"]:Embed("Admin",
								"**Passaporte:** " ..
								Passport .. "\n**Comando:** group " .. OtherPassport .. " " .. Permission .. " " .. Level,
								0xa3c846)
							TriggerClientEvent("Notify", source, "verde",
								"Adicionado <b>" .. Permission .. "</b> ao passaporte <b>" .. OtherPassport .. "</b>.",
								5000, "Sucesso")
							vRP.SetPermission(OtherPassport, Permission, Level)
						end
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "ungroup" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Grupo:")
				if Keyboard and vRP.CheckGroup(Keyboard[2]) then
					TriggerClientEvent("Notify", source, "verde",
						"Removido <b>" .. Keyboard[2] .. "</b> ao passaporte <b>" .. Keyboard[1] .. "</b>.", "Sucesso",
						5000)
					exports["vrp"]:Embed("Admin",
						"**Passaporte:** " .. Passport .. "\n**Comando:** ungroup " .. Keyboard[1] .. " " .. Keyboard[2],
						0xa3c846)
					vRP.RemovePermission(Keyboard[1], Keyboard[2])
					if vRP.GroupType(Keyboard[2]) == "Work" then
						vRP.RemovePermission(Keyboard[1], "Buff")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "tptome" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local ClosestPed = vRP.Source(Keyboard[1])
					if ClosestPed then
						local Ped = GetPlayerPed(source)
						local Coords = GetEntityCoords(Ped)

						vRP.Teleport(ClosestPed, Coords["x"], Coords["y"], Coords["z"])
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "tpto" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local ClosestPed = vRP.Source(Keyboard[1])
					if ClosestPed then
						local Ped = GetPlayerPed(ClosestPed)
						local Coords = GetEntityCoords(Ped)
						vRP.Teleport(source, Coords["x"], Coords["y"], Coords["z"])
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "tpway" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				IMPERIO_CLIENT.teleportWay(source)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "tuning" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				TriggerClientEvent("admin:Tuning", source)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "fix" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Vehicle, Network, Plate = vRPC.VehicleList(source, 10)
				if Vehicle then
					local Players = vRPC.Players(source)
					for _, v in pairs(Players) do
						async(function()
							TriggerClientEvent("inventory:repairAdmin", v, Network, Plate)
						end)
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "fuel" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				if not vRPC.InsideVehicle(source) then
					local Vehicle, Network, Plate = vRPC.VehicleList(source, 10)
					if Vehicle then
						local Keyboard = vKEYBOARD.Primary(source, "Litros:")
						if Keyboard then
							local Networked = NetworkGetEntityFromNetworkId(Network)
							Entity(Networked)["state"]:set("Fuel", Keyboard[1], true)
							TriggerClientEvent("Notify", source, "verde",
								"Veículo com <b>" .. parseInt(Keyboard[1]) .. "% de Gasolina</b>.", 5000, "Sucesso")
						end
					end
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa sair do veículo.", 5000, "Atenção")
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "limparea" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Ped = GetPlayerPed(source)
				local Coords = GetEntityCoords(Ped)
				IMPERIO_CLIENT.Limparea(source, Coords)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "hash" then
			if vRP.HasGroup(Passport, "Admin") then
				local Vehicle = vRPC.VehicleHash(source)
				if Vehicle then
					vKEYBOARD.Copy(source, "Hash do veículo:", Vehicle)
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "setbank" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Quantidade:")
				if Keyboard then
					vRP.GiveBank(Keyboard[1], Keyboard[2])
					TriggerClientEvent("Notify", source, "verde", "Envio concluído.", 5000, "Sucesso")
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "rembank" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Quantidade:")
				if Keyboard then
					vRP.RemoveBank(Keyboard[1], Keyboard[2])
					TriggerClientEvent("Notify", source, "verde", "Remoção concluída.", 5000, "Sucesso")
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "players" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				TriggerClientEvent("Notify", source, "azul", "<b>Jogadores Conectados:</b> " .. GetNumPlayerIndices(),5000)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "playersconnected" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local List = vRP.Players()
				local Players = ""
				for k, v in pairs(List) do
					local Identity = vRP.Identity(k)
					Players = Players .. k .. ": " .. Identity.name .. " ".. Identity.name2 .. "\n"
				end
				vKEYBOARD.Copy(source, "Players Conectados:", Players)
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "announce" then
			if vRP.HasGroup(Passport, "Admin", 3) then
				local Keyboard = vKEYBOARD.Quadruple(source, "Tema:", "Anúncio:", "Título:", "Segundos:")
				if Keyboard then
					TriggerClientEvent("Notify", -1, Keyboard[1], Keyboard[2], Keyboard[3], Keyboard[4] * 1000)
					exports["vrp"]:Embed("Admin",
						"**Passaporte:** " ..
						Passport ..
						"\n**Comando:** announce " ..
						Keyboard[1] .. " " .. Keyboard[2] .. " " .. Keyboard[3] .. " " .. Keyboard[4] * 1000, 0xa3c846)
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "setcar" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Veículo:")
				if Keyboard and Keyboard[1] and Keyboard[2] then
					if VehicleExist(Keyboard[2]) then
						local Consult = vRP.Query("vehicles/selectVehicles",
							{ Passport = Keyboard[1], vehicle = Keyboard[2] })
						if Consult[1] then
							TriggerClientEvent("Notify", source, "amarelo",
								"O passaporte <b>" .. Keyboard[1] .. "</b> já possui o veículo <b>" ..
								Keyboard[2] .. "</b>", 5000, "Atenção")
						else
							exports["vrp"]:Embed("Admin",
								"**Passaporte:** " .. Passport .. "\n**Comando:** setcar " ..
								Keyboard[1] .. " " .. Keyboard[2], 0xa3c846)
							vRP.Query("vehicles/addVehicles",
								{
									Passport = Keyboard[1],
									vehicle = Keyboard[2],
									plate = vRP.GeneratePlate(),
									work = "false"
								})
							TriggerClientEvent("Notify", source, "verde",
								"O veículo <b>" ..
								Keyboard[2] .. "</b> foi adicionado para o passaporte <b>" .. Keyboard[1] .. "<b>.",
								5000, "Sucesso")
						end
					else
						TriggerClientEvent("Notify", source, "amarelo", "Esse carro não existe.", 5000, "Atenção")
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "remcar" then
			if vRP.HasGroup(Passport, "Admin", 1) then
				local Keyboard = vKEYBOARD.Secondary(source, "ID:", "Veículo:")
				if Keyboard then
					exports["vrp"]:Embed("Admin",
						"**Passaporte:** " .. Passport .. "\n**Comando:** remcar " .. Keyboard[1] .. " " .. Keyboard[2],
						0xa3c846)
					TriggerClientEvent("Notify", source, "verde", "Veículo removido com sucesso.", 5000, "Sucesso")
					vRP.Query("vehicles/removeVehicles", { Passport = Keyboard[1], vehicle = Keyboard[2] })
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "clearprison" then
			if vRP.HasGroup(Passport, "Admin", 2) then
				local Keyboard = vKEYBOARD.Primary(source, "ID:")
				if Keyboard then
					local OtherPlayer = vRP.Source(Keyboard[1])
					if OtherPlayer then
						exports["vrp"]:Embed("Admin",
							"**Passaporte:** " .. Passport .. "\n**Comando:** clearprison " .. Keyboard[1], 0xa3c846)
						exports["markers"]:Exit(OtherPlayer)
						TriggerClientEvent("Notify", source, "verde", "Prisão zerada.", 5000, "Sucesso")
						vRP.Query("characters/CleanPrison", { Passport = Keyboard[1] })
						Player(OtherPlayer)["state"]["Prison"] = false
					end
				end
			else
				TriggerClientEvent("Notify", source, "amarelo", "Você não tem permissões para isso.", 5000, "Atenção")
			end
		elseif Mode == "stats" then
			local _, TotalPolicia = vRP.NumPermission("Policia")
			local _, TotalParamedico = vRP.NumPermission("Hospital")
			local _, TotalBombeiro = vRP.NumPermission("Bombeiro")

			TriggerClientEvent("Notify", source, "azul",
				"Atualmente <b>" ..
				parseInt(GetNumPlayerIndices()) ..
				"</b> pessoas conectadas.<br><br>Atualmente <b>" ..
				parseInt(TotalPolicia) ..
				" Policiais</b> conectados.<br>Atualmente <b>" ..
				parseInt(TotalParamedico) .. " Paramédicos</b> conectados.", ServerName, 10000)
		elseif Mode == "statsPolicia" then
			local _, TotalPolicia = vRP.NumPermission("Policia")
			TriggerClientEvent("Notify", source, "policia",
				"Existem <b>" .. parseInt(TotalPolicia) .. "</b> companheiros com você.", "Polícia", 5000)
		elseif Mode == "statsParamedico" then
			local _, TotalParamedico = vRP.NumPermission("Hospital")
			TriggerClientEvent("Notify", source, "hospital",
				"Existem <b>" .. parseInt(TotalParamedico) .. "</b> companheiros com você.", "Paramédico", 5000)
		elseif Mode == "statsBombeiro" then
				local _, TotalBombeiro = vRP.NumPermission("Bombeiro")
				TriggerClientEvent("Notify", source, "hospital","Existem <b>" .. parseInt(TotalBombeiro) .. "</b> companheiros com você.", "Paramédico", 5000)
		end
	end
end) 
*/
-----------------------------------------------------------------------------------------------------------------------------------------
-- SERVICE:TOGGLE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("service:Toggle")
AddEventHandler("service:Toggle",function(Service)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		vRP.ServiceToggle(source,Passport,Service,false)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- 
-----------------------------------------------------------------------------------------------------------------------------------------
local List = {
	["RádioPatrulha"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 8, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 200, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 137, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 27, texture = 0 },
				["tshirt"] = { item = 152, texture = 0 },
				["torso"] = { item = 88, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 49, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 13, texture = 2 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 8, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 200, texture = 0 },
				["accessory"] = { item = 1, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 10, texture = 1 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 3, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 3, texture = 0 },
				["torso"] = { item = 88, texture = 0 },
				["accessory"] = { item = 145, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 } 
			},
		},
		[3] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 13, texture = 2 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 111, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 149, texture = 4 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 6, texture = 0 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 3, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 3, texture = 0 },
				["torso"] = { item = 88, texture = 0 },
				["accessory"] = { item = 145, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[4] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 3, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 111, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 149, texture = 3 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 6, texture = 0 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 3, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 152, texture = 0 },
				["torso"] = { item = 88, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[5] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 0 },
				["shoes"] = { item = 111, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 149, texture = 2 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 28, texture = 2 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 3, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 88, texture = 0 },
				["accessory"] = { item = 1, texture = 1 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[6] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 74, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 2 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 200, texture = 7 },
				["accessory"] = { item = 200, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 28, texture = 2 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 3, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 192, texture = 0 },
				["accessory"] = { item = 151, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[7] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 15, texture = 14 },
				["vest"] = { item = -1, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = -1, texture = 0 },
				["decals"] = { item = -1, texture = 0 },
				["mask"] = { item = -1, texture = 0 },
				["shoes"] = { item = 2, texture = 0 },
				["tshirt"] = { item = 15, texture = 0 },
				["torso"] = { item = 73, texture = 16 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 0, texture = 0 },
				["glass"] = { item = -1, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = 28, texture = 0 },
				["pants"] = { item = 100, texture = 1 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 25, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 192, texture = 3 },
				["accessory"] = { item = 147, texture = 0 },
				["watch"] = { item = 27, texture = 2 },
				["arms"] = { item = 14, texture = 0 },
				["glass"] = { item = 5, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
	},
	["Rocam"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 17, texture = 0 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 149, texture = 4 },
				["accessory"] = { item = 1, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 209, texture = 0 },
				["glass"] = { item = 60, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 17, texture = 0 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 65, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 149, texture = 4 },
				["accessory"] = { item = 1, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 209, texture = 0 },
				["glass"] = { item = 60, texture = 0 },
				["ear"] = { item = -1, texture = 0 } 
			},
		},
	},
	["ForçaTática"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 121, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 72, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 0 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 44, texture = 1 },
				["torso"] = { item = 143, texture = 0 },
				["accessory"] = { item = 42, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 4, texture = 0 },
				["glass"] = { item = 60, texture = 0 },
				["ear"] = { item = -2, texture = 0 }
			}
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 121, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 72, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 52, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 2 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 44, texture = 0 },
				["torso"] = { item = 143, texture = 4 },
				["accessory"] = { item = 42, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 4, texture = 0 },
				["glass"] = { item = 60, texture = 0 },
				["ear"] = { item = -2, texture = 0 }
			},
		},
		[3] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 31, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 0 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 200, texture = 0 },
				["accessory"] = { item = 42, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[4] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 31, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 52, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 0 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 200, texture = 0 },
				["accessory"] = { item = 42, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 } 
			},
		},
	},
	["Bike"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 12, texture = 2 },
				["vest"] = { item = 4, texture = 3 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = -1, texture = 0 },
				["decals"] = { item = 8, texture = 0 },
				["mask"] = { item = -1, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 190, texture = 10 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 0, texture = 0 },
				["glass"] = { item = -1, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			}
		}
	},
	["Trânsito"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 13, texture = 0 },
				["pants"] = { item = 32, texture = 0 },
				["vest"] = { item = 14, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 8, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 33, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 190, texture = 9 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = 1, texture = 0 },
				["arms"] = { item = 0, texture = 0 },
				["glass"] = { item = 4, texture = 9 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 13, texture = 0 },
				["pants"] = { item = 32, texture = 0 },
				["vest"] = { item = 14, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 54, texture = 0 },
				["decals"] = { item = 8, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 33, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 190, texture = 9 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = 1, texture = 0 },
				["arms"] = { item = 0, texture = 0 },
				["glass"] = { item = 4, texture = 9 },
				["ear"] = { item = -1, texture = 0 } 
			},
		},
	},
	["Rpm"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 18, texture = 0 },
				["pants"] = { item = 32, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = -1, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 52, texture = 0 },
				["shoes"] = { item = 37, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 156, texture = 4 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 20, texture = 0 },
				["glass"] = { item = -1, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 18, texture = 0 },
				["pants"] = { item = 32, texture = 0 },
				["vest"] = { item = 4, texture = 3 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = -1, texture = 0 },
				["decals"] = { item = 8, texture = 0 },
				["mask"] = { item = 52, texture = 0 },
				["shoes"] = { item = 37, texture = 0 },
				["tshirt"] = { item = 57, texture = 0 },
				["torso"] = { item = 193, texture = 11 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 20, texture = 0 },
				["glass"] = { item = -1, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
	},
	["Dpm"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 33, texture = 0 },
				["vest"] = { item = 8, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 31, texture = 0 },
				["decals"] = { item = 8, texture = 0 },
				["mask"] = { item = 58, texture = 3 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 55, texture = 0 },
				["torso"] = { item = 200, texture = 0 },
				["accessory"] = { item = 8, texture = 0 },
				["watch"] = { item = 1, texture = 0 },
				["arms"] = { item = 0, texture = 0 },
				["glass"] = { item = -1, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
	},
	["Bope"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 121, texture = 0 },
				["pants"] = { item = 48, texture = 0 },
				["vest"] = { item = 16, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 33, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 1 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 16, texture = 0 },
				["torso"] = { item = 220, texture = 13 },
				["accessory"] = { item = 200, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 208, texture = 0 },
				["glass"] = { item = 9, texture = 9 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 121, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 72, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 33, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 2 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 243, texture = 0 },
				["torso"] = { item = 143, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 9, texture = 9 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
		[3] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 121, texture = 0 },
				["pants"] = { item = 25, texture = 2 },
				["vest"] = { item = 72, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 33, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 58, texture = 2 },
				["shoes"] = { item = 103, texture = 0 },
				["tshirt"] = { item = 243, texture = 0 },
				["torso"] = { item = 143, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 9, texture = 9 },
				["ear"] = { item = -1, texture = 0 }
			}
		},
	},

	["Pcerj"] = {
		[1] = { -- Acadepol
			["mp_m_freemode_01"] = {
        		["hat"] = { item = 121, texture = 0 },
        		["pants"] = { item = 87, texture = 0 },
        		["vest"] = { item = 69, texture = 0 },
        		["bracelet"] = { item = -1, texture = 0 },
        		["backpack"] = { item = 2, texture = 0 },
        		["decals"] = { item = 146, texture = 0 },
        		["mask"] = { item = 169, texture = 13 },
        		["shoes"] = { item = 110, texture = 0 },
        		["tshirt"] = { item = 131, texture = 0 },
        		["torso"] = { item = 73, texture = 9 },
        		["accessory"] = { item = 195, texture = 0 },
        		["watch"] = { item = -1, texture = 0 },
        		["arms"] = { item = 171, texture = 0 },
        		["glass"] = { item = 0, texture = 0 },
        		["ear"] = { item = -1, texture = 0 }
			}
    	},
    	[2] = { -- Agente Classe 3
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 87, texture = 0 },
    		    ["vest"] = { item = 22, texture = 8 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 169, texture = 13 },
    		    ["shoes"] = { item = 110, texture = 0 },
    		    ["tshirt"] = { item = 131, texture = 0 },
    		    ["torso"] = { item = 94, texture = 1 },
    		    ["accessory"] = { item = 193, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 171, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	},
    	[3] = { -- Agente Classe 2
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 87, texture = 0 },
    		    ["vest"] = { item = 22, texture = 8 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 169, texture = 13 },
    		    ["shoes"] = { item = 110, texture = 0 },
    		    ["tshirt"] = { item = 131, texture = 0 },
    		    ["torso"] = { item = 94, texture = 0 },
    		    ["accessory"] = { item = 193, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 171, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	},
    	[4] = { -- Agente Classe 1
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 87, texture = 0 },
    		    ["vest"] = { item = 22, texture = 8 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 169, texture = 13 },
    		    ["shoes"] = { item = 110, texture = 0 },
    		    ["tshirt"] = { item = 16, texture = 0 },
    		    ["torso"] = { item = 94, texture = 2 },
    		    ["accessory"] = { item = 197, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 171, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	},
    	[5] = { -- Agente Especial
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 87, texture = 0 },
    		    ["vest"] = { item = 7, texture = 0 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 0, texture = 0 },
    		    ["shoes"] = { item = 110, texture = 0 },
    		    ["tshirt"] = { item = 242, texture = 5 },
    		    ["torso"] = { item = 53, texture = 0 },
    		    ["accessory"] = { item = 200, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 171, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	},
		[6] = { -- Escrivão Civil
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 198, texture = 0 },
    		    ["vest"] = { item = 0, texture = 0 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 0, texture = 0 },
    		    ["shoes"] = { item = 111, texture = 0 },
    		    ["tshirt"] = { item = 160, texture = 0 },
    		    ["torso"] = { item = 36, texture = 0 },
    		    ["accessory"] = { item = 193, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 141, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	},
    	[7] = { -- Perito Civil
			["mp_m_freemode_01"] = {
    		    ["hat"] = { item = 121, texture = 0 },
    		    ["pants"] = { item = 130, texture = 0 },
    		    ["vest"] = { item = 7, texture = 2 },
    		    ["bracelet"] = { item = -1, texture = 0 },
    		    ["backpack"] = { item = 2, texture = 0 },
    		    ["decals"] = { item = 146, texture = 0 },
    		    ["mask"] = { item = 0, texture = 0 },
    		    ["shoes"] = { item = 110, texture = 0 },
    		    ["tshirt"] = { item = 242, texture = 5 },
    		    ["torso"] = { item = 311, texture = 9 },
    		    ["accessory"] = { item = 193, texture = 0 },
    		    ["watch"] = { item = -1, texture = 0 },
    		    ["arms"] = { item = 85, texture = 0 },
    		    ["glass"] = { item = 0, texture = 0 },
    		    ["ear"] = { item = -1, texture = 0 }
			}
    	}
	},
	
	["Hospital"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 20, texture = 0 },
				["vest"] = { item = 13, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 8, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 321, texture = 0 },
				["accessory"] = { item = 126, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 209, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 23, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 6, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 332, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 49, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 87, texture = 0 },
				["vest"] = { item = 13, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 154, texture = 0 },
				["torso"] = { item = 322, texture = 0 },
				["accessory"] = { item = 126, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 209, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 11, texture = 1 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 190, texture = 0 },
				["torso"] = { item = 27, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 85, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[3] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 126, texture = 0 },
				["vest"] = { item = 13, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 21, texture = 0 },
				["tshirt"] = { item = 200, texture = 0 },
				["torso"] = { item = 131, texture = 0 },
				["accessory"] = { item = 126, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 205, texture = 1 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 100, texture = 9 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 3, texture = 0 },
				["torso"] = { item = 257, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 111, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[4] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 147, texture = 3 },
				["vest"] = { item = 13, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 134, texture = 0 },
				["tshirt"] = { item = 129, texture = 0 },
				["torso"] = { item = 132, texture = 0 },
				["accessory"] = { item = 4, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 4, texture = 2 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 23, texture = 2 },
				["tshirt"] = { item = 3, texture = 0 },
				["torso"] = { item = 357, texture = 4 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 9, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			
		},
	},

	["Prf"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 10, texture = 3 },
				["pants"] = { item = 130, texture = 6 },
				["vest"] = { item = 28, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 62, texture = 6 },
				["tshirt"] = { item = 214, texture = 0 },
				["torso"] = { item = 273, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 23, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 6, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 332, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 49, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[2] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 10, texture = 3 },
				["pants"] = { item = 130, texture = 6 },
				["vest"] = { item = 5, texture = 3 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 62, texture = 6 },
				["tshirt"] = { item = 214, texture = 0 },
				["torso"] = { item = 166, texture = 0 },
				["accessory"] = { item = 0, texture = 0 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 1, texture = 0 },
				["glass"] = { item = 65, texture = 11 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 11, texture = 1 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 190, texture = 0 },
				["torso"] = { item = 27, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 85, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
		[3] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 130, texture = 6 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -1, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 0, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 62, texture = 6 },
				["tshirt"] = { item = 106, texture = 0 },
				["torso"] = { item = 166, texture = 0 },
				["accessory"] = { item = 200, texture = 1 },
				["watch"] = { item = -1, texture = 0 },
				["arms"] = { item = 4, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 100, texture = 9 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 24, texture = 0 },
				["tshirt"] = { item = 3, texture = 0 },
				["torso"] = { item = 257, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 111, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
	},

	["EastCustoms"] = {
		[1] = {
			["mp_m_freemode_01"] = {
				["hat"] = { item = 2, texture = 0 },
				["pants"] = { item = 185, texture = 2 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 99, texture = 0 },
				["tshirt"] = { item = 19, texture = 0 },
				["torso"] = { item = 208, texture = 0 },
				["accessory"] = { item = 212, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 198, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
			["mp_f_freemode_01"] = {
				["hat"] = { item = -1, texture = 0 },
				["pants"] = { item = 23, texture = 0 },
				["vest"] = { item = 0, texture = 0 },
				["bracelet"] = { item = -2, texture = 0 },
				["backpack"] = { item = 0, texture = 0 },
				["decals"] = { item = 161, texture = 0 },
				["mask"] = { item = 0, texture = 0 },
				["shoes"] = { item = 6, texture = 0 },
				["tshirt"] = { item = 189, texture = 0 },
				["torso"] = { item = 332, texture = 0 },
				["accessory"] = { item = 96, texture = 0 },
				["watch"] = { item = -2, texture = 0 },
				["arms"] = { item = 49, texture = 0 },
				["glass"] = { item = 0, texture = 0 },
				["ear"] = { item = -1, texture = 0 }
			},
		},
	},

	
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- 
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Presets(Group)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		return List[Group]
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PLAYER:PRESET
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("dynamic:Preset")
AddEventHandler("dynamic:Preset",function(Key)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Group,Preset = Key:match("(.-)-(.*)")
		local Model = vRP.ModelPlayer(source)
		if Model == "mp_m_freemode_01" or "mp_f_freemode_01" then

			print(List[Group][tonumber(Preset)][Model])
			TriggerClientEvent("skinshop:Apply",source,List[Group][tonumber(Preset)][Model])
		end
	end
end)